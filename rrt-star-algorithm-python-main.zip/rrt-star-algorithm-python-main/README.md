# RRT-Star-algorithm-Python
2D routing and path planning RRT* algorithm (Python)  
-- Incremental sampling & searching algorithm series --  

The RRT* algorithm progressively covers the area in a net of nodes, and dinamically improves and rewires edges to always find the shortest paths  

![alt text](https://github.com/ilariamarte/rrt-star-algorithms/blob/main/RRT-Star%20-%20Python/images/rrtp1.PNG)
![alt text](https://github.com/ilariamarte/rrt-star-algorithms/blob/main/RRT-Star%20-%20Python/images/rrtp2.PNG)
