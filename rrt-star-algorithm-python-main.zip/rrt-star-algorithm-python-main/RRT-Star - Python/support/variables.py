adjust_time = 10
[screen_width,screen_height] = [1000,600]
scale = 1 #4/5
check_edge = 1
start_prob = 60